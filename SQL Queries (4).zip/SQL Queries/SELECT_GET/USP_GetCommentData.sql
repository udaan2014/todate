

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from Comment table
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetCommentData
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT [UserId],
			[RegulationId],
			[Acceptance],
			[Description],
			[DateOfCreation],
			[DateOfModification] 
	FROM [Comment]  	
END
GO   