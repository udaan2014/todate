-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from department table
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetDepartmentData
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT [DepartmentId],
			[DepartmentName],
			[DateOfCreation] 
	FROM [Department]  	
END
GO   