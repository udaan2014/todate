
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from RegulationDepartment table
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetRegulationDepartmentData
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT [RegulationId],
			[DepartmentId],
			[EmployeeAccess] 
	FROM [RegulationDepartment]  	
END
GO   