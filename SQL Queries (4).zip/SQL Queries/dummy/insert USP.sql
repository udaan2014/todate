-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in User Table
-- ==============================================================================================================         
CREATE PROCEDURE USP_InsertUser
(
	--@UserId varchar(50),
	@UserName varchar(50),
	@Password varchar(255),	
	@RoleId int,
	@DepartmentId varchar(50),
	@DateOfJoining date,
	@DateOfBirth date,
	@EmailId varchar(50),
	@Phonenumber varchar(50),
	@Address varchar(255),
	@SecretQuestion varchar(255)
)
AS
BEGIN
	BEGIN TRY
		DECLARE @lastID varchar(50)
		DECLARE @userID varchar(50)
		DECLARE @UserId varchar(50)
		SET @lastID = ISNULL((SELECT MAX(UserId) FROM [User]), 'EMP0000')
		SET @lastID= SUBSTRING(@lastID,4,4)		
		SET @userID=CAST(@lastID AS int) +1		
		SET @UserId='EMP' + RIGHT(('0000'+@userID),4)		
		
		INSERT INTO [User]([UserId],[UserName],[Password],[RoleId],[DepartmentId],[DateOfJoining],[DateOfBirth],[EmailId],[Phonenumber],[Address],[SecretQuestion])  
		VALUES (@UserId,@UserName,@Password,@RoleId,@DepartmentId,@DateOfJoining,@DateOfBirth,@EmailId,@Phonenumber,@Address,@SecretQuestion)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in department Table
-- ==============================================================================================================            
CREATE PROCEDURE USP_InsertDepartment
(
	--@DepartmentId varchar(50),
	@DepartmentName varchar(50),
	@DateOfCreation date
)
AS
BEGIN
	BEGIN TRY
		DECLARE @lastID varchar(50)
		DECLARE @deptID varchar(50)
		DECLARE @DepartmentId varchar(50)
		SET @lastID = ISNULL((SELECT MAX(DepartmentId) FROM [Department]), 'DEPT00')
		SET @lastID= SUBSTRING(@lastID,5,2)		
		SET @deptID=CAST(@lastID AS int) +1		
		SET @DepartmentId='DEPT' + RIGHT(('00'+@deptID),2)

		INSERT INTO [Department]([DepartmentId],[DepartmentName],[DateOfCreation] )
		VALUES (@DepartmentId,@DepartmentName,@DateOfCreation)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in Role Table
-- ==============================================================================================================          

CREATE PROCEDURE USP_InsertRole
(	
	@RoleType varchar(50),
	@Description varchar(255)	
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [Role]([RoleType],[Description])
		VALUES (@RoleType,@Description)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO       
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in regulation Table
-- ==============================================================================================================       
CREATE PROCEDURE USP_InsertRegulation
(	
	@RegulationName varchar(50),
	@Description varchar(255),
	@Status varchar(50),
	@DateOfCreation date,
	@DateOfModification date	
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [Regulation]([RegulationName],[Description],[Status],[DateOfCreation],[DateOfModification])
		VALUES (@RegulationName,@Description,@Status,@DateOfCreation,@DateOfModification)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO 

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in RegulationDepartment table
-- ==============================================================================================================     
CREATE PROCEDURE USP_InsertRegulationDepartment
(
	@RegulationId int,
	@DepartmentId varchar(50),
	@EmployeeAccess bit	
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [RegulationDepartment]([RegulationId],[DepartmentId],[EmployeeAccess])
		VALUES (@RegulationId,@DepartmentId,@EmployeeAccess)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO 



-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in comment table
-- ==============================================================================================================     
CREATE PROCEDURE USP_InsertComment
(
	@UserId varchar(50),
	@RegulationId int,
	@Acceptance bit,
	@Description varchar(255),
	@DateOfCreation date,
	@DateOfModification date
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [Comment]([UserId],[RegulationId],[Acceptance],[Description],[DateOfCreation],[DateOfModification])
		VALUES (@UserId,@RegulationId,@Acceptance,@Description,@DateOfCreation,@DateOfModification)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO                                                                                                                                                                                                                                                                                                                                                                                                                                              