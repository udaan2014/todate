
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Foreign keys for the tables
-- ==============================================================================================================
ALTER TABLE [User]
	ADD CONSTRAINT FK_User_Role_RoleId
	FOREIGN KEY (RoleId) REFERENCES [Role]([RoleId]) ON DELETE CASCADE 
GO

ALTER TABLE [User]
	ADD CONSTRAINT FK_User_Department_DepartmentId
	FOREIGN KEY (DepartmentId) REFERENCES [Department]([DepartmentId]) ON DELETE CASCADE 
GO

ALTER TABLE [RegulationDepartment]
	ADD CONSTRAINT FK_RegulationDepartment_Department_DepartmentId
	FOREIGN KEY (DepartmentId) REFERENCES [Department]([DepartmentId]) ON DELETE CASCADE 
GO

ALTER TABLE [RegulationDepartment]
	ADD CONSTRAINT FK_RegulationDepartment_Regulation_RegulationId
	FOREIGN KEY (RegulationId) REFERENCES [Regulation]([RegulationId]) ON DELETE CASCADE 
GO

ALTER TABLE [Comment]
	ADD CONSTRAINT FK_Comment_User_UserId
	FOREIGN KEY (UserId) REFERENCES [User]([UserId]) ON DELETE CASCADE 
GO

ALTER TABLE [Comment]
	ADD CONSTRAINT FK_Comment_Regulation_RegulationId
	FOREIGN KEY (RegulationId) REFERENCES [Regulation]([RegulationId]) ON DELETE CASCADE 
GO