
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables: User 
-- ==============================================================================================================
CREATE TABLE [User]
(
	[UserId] varchar(50),	
	[UserName] varchar(50),
	[Password] varchar(255),
	[RoleId] int,
	[DepartmentId] varchar(50),
	[DateOfJoining] date DEFAULT GETDATE(),
	[DateOfBirth] date,
	[EmailId] varchar(50),
	[Phonenumber] varchar(50),
	[Address] varchar(255),
	[SecretQuestion] varchar(255),
	CONSTRAINT PK_User_UserId PRIMARY KEY ([UserId])
)
GO