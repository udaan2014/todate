
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Role
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateRoleData
(
	@RoleId int,
	@RoleType varchar(50),
	@Description varchar(255)
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Role] SET
		[RoleType]=ISNULL(@RoleType,RoleType),
		[Description]= ISNULL(@Description,Description)		
		WHERE [RoleId] = @RoleId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
