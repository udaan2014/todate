
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Department
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateDepartmentData
(
	@DepartmentId varchar(50),
	@DepartmentName varchar(50),
	@DateOfCreation date
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Department] SET
		[DepartmentName]= ISNULL(@DepartmentName,DepartmentName),
		[DateOfCreation]=ISNULL(@DateOfCreation,DateOfCreation)		
		WHERE [DepartmentId] = @DepartmentId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
