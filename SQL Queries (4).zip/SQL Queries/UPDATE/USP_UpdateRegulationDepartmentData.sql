
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables RegulationDepartment
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateRegulationDepartmentData
(
	@RegulationId int,
	@DepartmentId varchar(50),
	@EmployeeAccess bit
)
AS
BEGIN
	BEGIN TRY
		UPDATE [RegulationDepartment] SET
		[EmployeeAccess]=ISNULL(@EmployeeAccess,EmployeeAccess)			
		WHERE [RegulationId] = @RegulationId AND [DepartmentId] = @DepartmentId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO