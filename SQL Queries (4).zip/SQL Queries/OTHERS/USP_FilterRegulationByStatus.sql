
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for Returning set of Regulations for the matching status
-- ==============================================================================================================    
CREATE PROCEDURE USP_FilterRegulationByStatus
(
	@Status bit
)
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT [RegulationId],
			[RegulationName],
			[Description],
			[Status],
			[DateOfCreation],
			[DateOfModification] 
	FROM [Regulation] 
	WITH(NOLOCK) 
	WHERE [Status]=@Status	
END
GO   