
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Stored Procedure for Selecting Old Regulations for Notifying Department Head
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetOldRegulationsForDepartmentHead
(
	@DepartmentId varchar(50)
)
AS
BEGIN	
	SET NOCOUNT ON;	
	SELECT R.[RegulationId],
			R.[RegulationName],
			R.[Description],
			R.[Status],
			R.[DateOfCreation],
			R.[DateOfModification] 
	FROM [Regulation] AS R WITH(NOLOCK) INNER JOIN [RegulationDepartment] AS RD	
	ON R.[RegulationId]=RD.[RegulationId] 
	WHERE RD.[DepartmentId]=@DepartmentId AND RD.[EmployeeAccess]=1	
END
GO   