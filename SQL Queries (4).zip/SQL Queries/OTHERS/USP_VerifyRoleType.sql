
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for verifying Role Type
-- ==============================================================================================================    
CREATE PROCEDURE USP_VerifyRoleType
(
	@RoleType varchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;		
	SELECT RoleId,RoleType FROM [Role]
	WITH(NOLOCK) 		
	WHERE [RoleType]=@RoleType
END
GO  