-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Store Procedure for Forwarding regulations to Employee from Department head dashboard
-- ==============================================================================================================

CREATE PROCEDURE USP_ForwardRegulationToEmployee
(
	@RegulationId int,
	@DepartmentId varchar(50)	
)
AS
BEGIN
	BEGIN TRY
		UPDATE [RegulationDepartment] SET [EmployeeAccess]= 1		
		WHERE [RegulationId] = @RegulationId AND [DepartmentId]=@DepartmentId	
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO