
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for verifying Phonenumber at the time of Registration
-- ==============================================================================================================    
CREATE PROCEDURE USP_VerifyUserPhonenumber
(
	@Phonenumber varchar(50)
)
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT COUNT(UserId) FROM [User]
	WITH(NOLOCK) 		
	WHERE [Phonenumber]=@Phonenumber
END
GO  