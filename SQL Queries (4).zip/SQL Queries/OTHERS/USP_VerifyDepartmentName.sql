
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for verifying Department Name
-- ==============================================================================================================    
CREATE PROCEDURE USP_VerifyDepartmentName
(
	@DepartmentName varchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;		
	SELECT DepartmentId,DepartmentName FROM [Department]
	WITH(NOLOCK) 		
	WHERE [DepartmentName]=@DepartmentName
END
GO  