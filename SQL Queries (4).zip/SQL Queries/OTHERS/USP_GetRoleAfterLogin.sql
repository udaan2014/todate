
-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On : 1-2-2018
-- Description: Created the Store Procedure returning the Role type of a particular user using his UserID

-- ==============================================================================================================
CREATE PROCEDURE USP_GetRoleAfterLogin
(
	@UserId varchar(50)
)
AS
BEGIN	
	SET NOCOUNT ON
	SELECT R.RoleType FROM [User] AS L INNER JOIN [Role] AS R ON  L.RoleId= R.RoleId AND L.UserId=@UserId	
END
GO