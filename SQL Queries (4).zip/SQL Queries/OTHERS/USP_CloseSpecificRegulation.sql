-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Closing Specific Regulation from the admin end
-- ==============================================================================================================

CREATE PROCEDURE USP_CloseSpecificRegulation
(
	@RegulationId int	
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Regulation] SET	[Status]= 0		
		WHERE [RegulationId] = @RegulationId		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO