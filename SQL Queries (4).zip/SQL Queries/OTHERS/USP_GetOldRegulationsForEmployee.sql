
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Stored Procedure for Selecting Old Regulations for Employee
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetOldRegulationsForEmployee
(
	@UserId varchar(50),
	@DepartmentId varchar(50)
)
AS
BEGIN	
	SET NOCOUNT ON;	
	SELECT R.[RegulationId],
			R.[RegulationName],
			R.[Description],
			R.[Status],
			R.[DateOfCreation],
			R.[DateOfModification] 
	FROM [Regulation] AS R 
	WITH(NOLOCK) 
	INNER JOIN [RegulationDepartment] AS RD	
	ON R.[RegulationId]=RD.[RegulationId]
	WHERE RD.[DepartmentId]=@DepartmentId
	AND RD.[RegulationId] IN (SELECT C.[RegulationId] FROM [Comment] AS C WHERE C.[UserId]=@UserId )
	
END
GO   
