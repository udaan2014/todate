-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Searching for Particular Department
-- ==============================================================================================================    
CREATE PROCEDURE USP_SearchDepartmentData
(
	@DepartmentId int
)
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT [DepartmentId],
			[DepartmentName],
			[DateOfCreation] 
	FROM [Department]  WITH(NOLOCK) WHERE [DepartmentId]=@DepartmentId	
END
GO   