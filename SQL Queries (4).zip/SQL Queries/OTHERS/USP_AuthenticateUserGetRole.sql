-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On :3-2-2018
-- Description: Created the Store Procedures for User Authentication during Login time and Get his Role Type
-- ==============================================================================================================
CREATE PROCEDURE USP_AuthenticateUserGetRole
(
	@UserId varchar(50),
	@Password varchar(50)
)
AS
BEGIN
	SET NOCOUNT ON
	SELECT R.RoleType FROM [User] AS U 
	WITH(NOLOCK) 
	INNER JOIN [Role] AS R ON  U.RoleId= R.RoleId
	WHERE U.[UserId]= @UserId AND U.[Password]= @Password
	
END

