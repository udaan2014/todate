-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for Searching for Particular User
-- ==============================================================================================================    
CREATE PROCEDURE USP_SearchUserData
(
	@UserId int
)
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT [UserId],
			[UserName],
			[Password],
			[RoleId],
			[DepartmentId],
			[DateOfJoining],
			[DateOfBirth],
			[EmailId],
			[Phonenumber],
			[Address],
			[SecretQuestion]
	FROM [User]  WHERE [UserId]=@UserId
END
GO   