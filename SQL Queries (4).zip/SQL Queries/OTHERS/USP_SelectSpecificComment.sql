
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for returning Comments for a particular Regulation
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectSpecificComment
(
	@RegulationId int,
	@DepartmentId varchar(50)
)
AS
BEGIN	
	SET NOCOUNT ON;		
	SELECT C.[UserId],C.[Description], C.[Acceptance] FROM[Comment] AS C
	WITH(NOLOCK) 
	INNER JOIN [RegulationDepartment] AS RD 
	ON C.[RegulationId]= RD.[RegulationId]
	WHERE RD.[RegulationId]=@RegulationId AND RD.[DepartmentId]=@DepartmentId	
END
GO   