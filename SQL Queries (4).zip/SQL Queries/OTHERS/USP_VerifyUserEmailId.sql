
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-2-2018
-- Description: Query for Creating Store Procedure for verifying EmailId at the time of Registration
-- ==============================================================================================================    
CREATE PROCEDURE USP_VerifyUserEmailId
(
	@EmailId varchar(50)
)
AS
BEGIN
	SET NOCOUNT ON;		
	SELECT COUNT(UserId) FROM [User]
	WITH(NOLOCK) 		
	WHERE [EmailId]=@EmailId	
END
GO  