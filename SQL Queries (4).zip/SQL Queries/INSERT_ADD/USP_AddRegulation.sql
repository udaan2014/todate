
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in regulation Table
-- ==============================================================================================================       
CREATE PROCEDURE USP_AddRegulation
(	
	@RegulationName varchar(50),
	@Description varchar(255),
	--@Status bit,
	@DateOfCreation date,
	@DateOfModification date	
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [Regulation]([RegulationName],[Description],[DateOfCreation],[DateOfModification])
		VALUES (@RegulationName,@Description,@DateOfCreation,@DateOfModification)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO 